Challenge name: APT 514


Important notes:

1. All Timestamps answers must be in UTC and should be in the following format: YYYY-MM-DD HH:MM:SS

2. I recommend you to take note of all your answers as you may need them as you progress in the challenge or in case if the connection times out. 

3. I recommend using Windows OS to complete the challenge to avoid any unnecessary or extra steps.














Author: Houssem0x1

Author link: https://www.linkedin.com/in/ahmed-houssem-boualem-a07767305/